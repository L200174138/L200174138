<html>
<head>
	<title>Program Penjumlahan</title>
</head>
<body>
<form method="POST" action="penjumlahan.php">
	<p>Nilai A adalah : <input type="text" name="nilaiA" size="3"></p>
	<p>Nilai B adalah : <input type="text" name="nilaiB" size="3"></p>
	<p><input type="submit" value="Jumlahkan" name="submit"></p>
<?php
/*error_reporting (E_ALL ^ E_NOTICE);
$nilaiA = $_POST["nilaiA"];
$nilaiB = $_POST["nilaiB"];
$submit = $_POST["submit"];
if ($submit) {
	echo "Nilai A adalah $nilaiA</br>";
	echo "Nilai B adalah $nilaiB</br>";
	$C= $nilaiA+$nilaiB;
	echo "Jadi Nilai A ditambah nilai B adalah $C";
}*/
$nilaiA = $_POST["nilaiA"];
$nilaiB = $_POST["nilaiB"];
$jumlah=$_POST["nilaiA"]+$_POST["nilaiB"];
        echo "Nilai A adalah $nilaiA</br>";
		echo "Nilai B adalah $nilaiB</br>";
        echo"Jadi Nilai A ditambah nilai B adalah $jumlah";
?>
</form>
</body>
</html>